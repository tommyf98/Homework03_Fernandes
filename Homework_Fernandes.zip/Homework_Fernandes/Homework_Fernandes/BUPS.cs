﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/26/2021
 * Purpose: Homework 3
 * Caveats: No problem at all however I just did not know how to use Array inside the if statement. 
 */
namespace Homework_Fernandes
{
    class Program
    {
        static void Main(string[] args)
        {
            const double OVER_TWELVE_PACKAGE = 0.07;
            string YesOrNoInsurance;
            string TwoDayServiceRequested;
            const double OVER_15_POUND = 8.95;
            const double LESS_15_POUND = 6.75;
            const double INSURANCE_COST = 1.75;
            const double SUBCHARGE_COST = 1.40;
            const double TWO_DAY_DELIVERY_OVER_15_POUND = 1.40;
            const double TWO_DAY_DELIVERY_LESS_15_POUND = 1.00;
            string NoInsurance = "Refused";
            string NoTwoDayDelivery = "Standard Delivery Requested";

            Console.WriteLine("~~~ Welcome to BUPS Calculator! ~~~");





            Console.WriteLine("How many packages are over 15 pounds:");
            double NumberOfPackageOver15Pound = double.Parse(Console.ReadLine());
            Console.WriteLine("How many packages are 15 pounds or less");
            double NumberOfPackageLess15Pound = double.Parse(Console.ReadLine());
            Console.WriteLine("Insurance Requested (Yes/No): ");
            YesOrNoInsurance = Console.ReadLine();
            Console.WriteLine("Two-Day Service Requested (Yes/No): ");
            TwoDayServiceRequested = Console.ReadLine();


            double EightDollar95Sale = NumberOfPackageOver15Pound * OVER_15_POUND;
            double Six75Sale = NumberOfPackageLess15Pound * LESS_15_POUND;
            double Subtotal = EightDollar95Sale + Six75Sale;
            double TotalOver15Insurance = SUBCHARGE_COST * NumberOfPackageOver15Pound;
            double TotalLess15Insurance = INSURANCE_COST * NumberOfPackageLess15Pound;
            double TotalOver15TwoDayDelivery = TWO_DAY_DELIVERY_OVER_15_POUND * NumberOfPackageOver15Pound;
            double TotalLess15TwoDayDelivery = TWO_DAY_DELIVERY_LESS_15_POUND * NumberOfPackageLess15Pound;
            double TotalInsuranceSubcharge = TotalOver15Insurance + TotalLess15Insurance;
            double TotalTwoaDayDeliverySubcharge = TotalOver15TwoDayDelivery + TotalLess15TwoDayDelivery;
            double TotalCostInsuranceAndTotalTodayDeliverySubcharge = Subtotal + TotalInsuranceSubcharge;


            if (YesOrNoInsurance == "Yes")
            {
                if (TwoDayServiceRequested == "Yes")
                {
                    Console.WriteLine();
                    Console.WriteLine("How many packages are over 15 pounds: {0}", NumberOfPackageOver15Pound);
                    Console.WriteLine("How many packages are 15 pounds or less: {0}", NumberOfPackageLess15Pound);
                    Console.WriteLine("Insurance Requested (Yes/No): {0}",YesOrNoInsurance);
                    Console.WriteLine("Two-Day Service Requested (Yes/No): {0}", TwoDayServiceRequested);
                    Console.WriteLine("_________________________________");
                    Console.WriteLine("******* R E C E I P T *******");
                    Console.WriteLine("{0} packages at ${1:C}        ${2:C}", NumberOfPackageOver15Pound, OVER_15_POUND, EightDollar95Sale);
                    Console.WriteLine("{0} packages at ${1:C}        ${2:C}", NumberOfPackageLess15Pound, LESS_15_POUND, Six75Sale);
                    Console.WriteLine("                    Subtotal: ${0:C}", Subtotal);
                    Console.WriteLine();
                    Console.WriteLine("Discount Applied              ${0:C}", OVER_TWELVE_PACKAGE);
                    Console.WriteLine("Insurance Surcharge:          ${0:C}", TotalInsuranceSubcharge);
                    Console.WriteLine("Two-Day Delivery Sucharge:    ${0:C}", TotalTwoaDayDeliverySubcharge);
                    Console.WriteLine("Total Aount:                  ${0:C}", TotalCostInsuranceAndTotalTodayDeliverySubcharge);
                    Console.WriteLine("******* R E C E I P T *******");


                }
                else
                {
                    Console.WriteLine("Error input..... Please Pick Yes or No.");
                }
            }

            else if (YesOrNoInsurance == "No")
            {
                if (TwoDayServiceRequested == "No")
                {
                    double EightDollar95SaleOne = NumberOfPackageOver15Pound * OVER_15_POUND;
                    double Six75SaleOne = NumberOfPackageLess15Pound * LESS_15_POUND;
                    double SubtotalOne = EightDollar95Sale + Six75Sale;
                    double TotalCostNoProtection = Subtotal;
                    double discountMath = OVER_TWELVE_PACKAGE * SubtotalOne;
                    double discountTotal = discountMath;


                    Console.WriteLine();
                    Console.WriteLine("How many packages are over 15 pounds: {0}", NumberOfPackageOver15Pound);
                    Console.WriteLine("How many packages are 15 pounds or less: {0}", NumberOfPackageLess15Pound);
                    Console.WriteLine("Insurance Requested (Yes/No): {0}", YesOrNoInsurance);
                    Console.WriteLine("Two-Day Service Requested (Yes/No): {0}", TwoDayServiceRequested);
                    Console.WriteLine("_________________________________");
                    Console.WriteLine("******* R E C E I P T *******");
                    Console.WriteLine("{0} packages at ${1:C}        ${2:C}", NumberOfPackageOver15Pound, OVER_15_POUND, EightDollar95Sale);
                    Console.WriteLine("{0} packages at ${1:C}        ${2:C}", NumberOfPackageLess15Pound, LESS_15_POUND, Six75Sale);
                    Console.WriteLine("                    Subtotal: ${0:C}", SubtotalOne);
                    Console.WriteLine();
                    Console.WriteLine("Discount Applied              ${0:C}", discountMath);
                    Console.WriteLine("Insurance Surcharge:          ${0:C}", NoInsurance);
                    Console.WriteLine("Two-Day Delivery Sucharge:    ${0:C}", NoTwoDayDelivery);
                    Console.WriteLine("Total Aount:                  ${0:C}", TotalCostNoProtection);
                    Console.WriteLine("******* R E C E I P T *******");
                }
                else
                {
                    Console.WriteLine("Error input..... Please Pick Yes or No.");
                }

            }


        }
    }
}

